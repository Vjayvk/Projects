package SdbmsImpUtilization;

import java.util.Scanner;

import CustomException.InvalidChoiceException;
import StudentDBManagementSystem.StudentMS;
import StudentDBManagementSystem.StudentMSimpl;

public class Solution {

	public static void main(String[] args) {
		System.out.println(" Welcome To Student DataBase Management System !");
		System.out.println("---------------");
		Scanner ip=new Scanner(System.in);
		StudentMS s1=new StudentMSimpl();
		while(true)
		{
			System.out.println("1.addStudent\n2.displayStudent\n3.dispalyAllStudents\n4.removeStudent\n5.removeAllStudents\n6.updateStudent\n7.countStudent\n8sortStudent\n9.getByHighestMarks\n10.getByLowestMarks\n11.Exit.");
			System.out.println(" Enter the Choice");
			int choice=ip.nextInt();
			switch (choice) {

			case 1:s1.addStudent();
			break;
			case 2:s1.displayStudent();
			break;
			case 3:s1.displayAllStudents();
			break;
			case 4:s1.removeStudent();
			break;
			case 5:s1.removeAllStudents();
			break;
			case 6:s1.updateStudnet();
			break;
			case 7:s1.countStudent();
			break;
			case 8:s1.sortStudent();
			break;
			case 9:s1.getStudnetByHighestMarks();
			break;
			case 10:s1.getStudnetByLowestMarks();
			break;
			case 11:  System.out.println(" Thank You Vist Again !!!");
			System.exit(0);
			break;
			default:
				try
				{
					throw new InvalidChoiceException(" Invalid Choice  , Kindly Enter The valid Choice !!");
				}
				catch (Exception e) {
					e.getMessage();
				}


			}//end of switch
			System.out.println("-------------");

		}// end of while

	}
}
