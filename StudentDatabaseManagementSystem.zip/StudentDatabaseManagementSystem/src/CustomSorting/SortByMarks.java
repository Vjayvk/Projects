package CustomSorting;

import java.util.Comparator;

import StudentDBManagementSystem.Student;

public class SortByMarks implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		
		Double x=o1.getMarks();
		Double y=o2.getMarks();
		return x.compareTo(y);
	}

}
