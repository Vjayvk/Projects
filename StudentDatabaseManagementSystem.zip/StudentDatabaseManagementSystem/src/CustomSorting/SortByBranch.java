package CustomSorting;

import java.util.Comparator;

import StudentDBManagementSystem.Student;

public class SortByBranch implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		
		return  o1.getBranch().compareTo(o2.getBranch());
	}

}
