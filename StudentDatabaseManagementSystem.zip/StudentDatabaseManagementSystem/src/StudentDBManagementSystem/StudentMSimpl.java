package StudentDBManagementSystem;


import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import CustomException.InvalidChoiceException;
import CustomException.StudentNotFoundException;
import CustomSorting.SortByAge;
import CustomSorting.SortByID;
import CustomSorting.SortByMarks;
import CustomSorting.SortByName;

public class StudentMSimpl  implements StudentMS{

	Scanner ip=new Scanner(System.in);
	Map<String, Student> db=new LinkedHashMap<>();

	// collections Database 
	@Override
	public void addStudent() {
		System.out.println(" Enter the Student Name :");
		String name=ip.next();
		System.out.println(" Enter the Student Branch :");
		String branch=ip.next();
		System.out.println(" Enter The Student age :");
		int age=ip.nextInt();
		System.out.println(" Enter the Student Phone Number");
		long phno=ip.nextLong();
		System.out.println(" Enter the Student Marks");
		int marks=ip.nextInt();

		Student s=new Student(name, branch, age, marks, phno);
		db.put(s.getId(), s);
		System.out.println(" Student Data registered Successfully ");
		System.out.println(" Student Registration Id : "+s.getId());

	}

	@Override
	public void displayStudent() {
		System.out.println(" Enter the Registration Id :");
		String id=ip.next().toUpperCase();
		if(db.containsKey(id))
		{
			Student s=db.get(id);
			System.out.println(" Student RID : "+s.getId() );
			System.out.println(" Student Name : "+s.getName() );
			System.out.println(" Student Branch : "+s.getBranch() );
			System.out.println(" Student Age  : "+s.getAge() );
			System.out.println(" Student Phone : "+s.getPhno() );
			System.out.println(" Student Marks : "+s.getMarks() );
		}
		else
		{
			try
			{
				String message="Student with "+id+" Not Found ";
				throw new  StudentNotFoundException(message);
			}
			catch (Exception e) {
				e.getMessage();
			}
		}

	}

	@Override
	public void displayAllStudents() {
		if(db.size()!=0)
		{

			System.out.println(" Student Details As follows !!");
			System.out.println("-----------");
			Set<String> keys=db.keySet();//jsp1,jsp2,jsp3
			for(String key:keys)
			{
				Student st=db.get(key);
				System.out.println(st);
			}
		}
		else
		{
			try {

				String mess="   Students Are Not  Present , Nothing To Display !!  ";
				throw new StudentNotFoundException(mess);
			} catch (Exception e) {
				e.getMessage();
			}

		}

	}

	@Override
	public void removeStudent() {

		System.out.println(" Enter the Registration Id :");
		String id=ip.next().toUpperCase();
		if(db.containsKey(id))
		{
			Student s=db.get(id);
			System.out.println(" Student Record Found  with the Id :"+ s.getId()  );
			db.remove(id);
			System.out.println(" Student Data Deleted Successfully!!");
		}
		else
		{
			try
			{
				String message="Student with "+id+" Not Found ";
				throw new  StudentNotFoundException(message);
			}
			catch (Exception e) {
				e.getMessage();
			}
		}


	}

	@Override
	public void removeAllStudents() {

		if(db.size()!=0)
		{

			System.out.println(" Student Details with size  !! :"+db.size());
			db.clear();
			System.out.println(" All Student Details Deleted Successfully !! ");
			System.out.println(" Student size After ! : "+db.size());
		}
		else
		{
			try {

				String mess=" Students Are Not  Present , Nothing To Delete !!  ";
				throw new StudentNotFoundException(mess);
			} catch (Exception e) {
				e.getMessage();
			}

		}

	}

	@Override
	public void updateStudnet() {

		System.out.println(" Enter the Registration Id :");
		String id=ip.next().toUpperCase();
		if(db.containsKey(id))
		{
			Student s=db.get(id);
			System.out.println(" Student Record Found  with the Id :"+ s.getId()  );
			System.out.println("1.Update Name\n2.Update Branch \n3.Update Age\n4.Update Phno\n5.Update Marks\n6.Exit");
			System.out.println(" Enter the choice :");
			int ch=ip.nextInt();
			switch (ch) {
			case 1: System.out.println(" Enter the Student Name :");
			String name=ip.next();
			s.setName(name);
			break;
			case 2:System.out.println(" Enter the Student Branch :");
			String branch=ip.next();
			s.setBranch(branch);
			break;
			case 3: System.out.println(" Enter The Student age :");
			int age=ip.nextInt();
			s.setAge(age);
			break;
			case 4:System.out.println(" Enter the Student Phone Number");
			long phno=ip.nextLong();
			s.setPhno(phno);
			break;
			case 5:
				System.out.println(" Enter the Student Marks");
				int marks=ip.nextInt();
				s.setMarks(marks);
				break;
			case 6: System.out.println("Update Exists ");
			System.exit(0);
			default:try
			{

				throw new InvalidChoiceException(" Invalid Choice !! to Update ");

			}
			catch (Exception e) {
				e.getMessage();
			}

			}	

		}
		else
		{
			try
			{
				String message="Student with "+id+" Not Found ";
				throw new  StudentNotFoundException(message);
			}
			catch (Exception e) {
				e.getMessage();
			}

		}


	}

	@Override
	public void countStudent() {
		if(db.isEmpty()!=true)
		{
			System.out.println(" No of Students Present In db : "+db.size());
		}
		else
		{

			try
			{
				String message="Student with Data Base is Empty , Kindly Insert Students !!";
				throw new  StudentNotFoundException(message);
			}
			catch (Exception e) {
				e.getMessage();
			}
		}

	}

	@Override
	public void sortStudent() {
		if(db.size()>=2)
		{
			Set<String> s=db.keySet();
			ArrayList<Student> l=new ArrayList<>();
			for(String s1:s)
			{
				l.add(db.get(s1));
			}
			System.out.println("1.SortById\n2.SortByName\n3.SortByMarks\n4.SortByAge");
			System.out.println(" Enter Choice");
			int choice =ip.nextInt();
			switch(choice)
			{
			case 1: Collections.sort(l,new SortByID());
			display(l);
			break;
			case 2:Collections.sort(l,new SortByName());
			display(l);
			break;
			case 3:Collections.sort(l,new SortByMarks());
			display(l);
			break;
			case 4: Collections.sort(l,new SortByAge());
			display(l);
			break;
			default:
				try
				{
					throw new InvalidChoiceException(" Invalid Choice  !!");
				}
				catch (Exception e) {
					e.getMessage();
				}
			}
		}
		else
		{
			try
			{
				throw new StudentNotFoundException(" Not Enough Student Sort  ");
			}
			catch (Exception e) {
				e.getMessage();
			}
		}




	}
	public static void display(List<Student> l)
	{
		for(Student k:l)
		{
			System.out.println(k);
		}
	}
	@Override
	public void getStudnetByHighestMarks() {

		if(db.size()>=2)
		{
			Set<String> s=db.keySet();
			ArrayList<Student> l=new ArrayList<>();
			for(String s1:s)
			{
				l.add(db.get(s1));
			}
			Collections.sort(l,new SortByMarks());
			System.out.println(l.get(l.size()-1));

		}

	}

	@Override
	public void getStudnetByLowestMarks() {

		if(db.size()>=2)
		{
			Set<String> s=db.keySet();
			ArrayList<Student> l=new ArrayList<>();
			for(String s1:s)
			{
				l.add(db.get(s1));
			}
			Collections.sort(l,new SortByMarks());
			System.out.println(l.get(0));

		}
	}

}
