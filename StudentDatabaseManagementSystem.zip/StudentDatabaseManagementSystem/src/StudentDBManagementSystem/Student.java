package StudentDBManagementSystem;

public class Student {

	private static  String id;
	private String name;
	private String branch;
	private int age;
	private double marks;
	private  long phno;
	static  int count=1;
	public Student(String name, String branch, int age, double marks, long phno) {
		super();
		this.id="JSP"+count;
		this.name = name;
		this.branch = branch;
		this.age = age;
		this.marks = marks;
		this.phno = phno;
		count++;
	}
	public static String getId() {
		return id;
	}
	public static void setId(String id) {
		Student.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", branch=" + branch + ", age=" + age + ", marks=" + marks + ", phno=" + phno
				+ "]";
	}
	
	
}
