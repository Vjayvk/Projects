package StudentDBManagementSystem;

public interface StudentMS {
// achieving abstraction with declaring abstract methods
	
	void addStudent();
	void displayStudent();
	void displayAllStudents();
	void removeStudent();
	void removeAllStudents();
	void updateStudnet();
	void countStudent();
	void sortStudent();
	void getStudnetByHighestMarks();
	void getStudnetByLowestMarks();
	
	
}
